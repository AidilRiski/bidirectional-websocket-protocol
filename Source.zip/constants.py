FRAME_SIZE = 2**32 - 1
PORT =  65001

# Control frames
CLOSE = 8
PING = 9
PONG = 10

FILE_NAME = 'Source'
EXTENSION_NAME = 'zip'